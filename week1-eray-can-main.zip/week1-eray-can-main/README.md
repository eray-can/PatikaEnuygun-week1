# week1-eray-can
week1-eray-can created by GitHub Classroom


1-OOP Nedir?

*Nesne yönelimli programlama Yazılımın karmaşıklığını azaltmak için kullanılır.Farklı bir yazılımcı koda baktığı zaman kod karmaşıklığı olmadan sade ve nesne yönelimli programlamaya uygun kodlar olması lazım ki yazdığımız kodlar geliştirmeye ve okunmaya açık olsun.

2-Polymorphism ne amaçlı kullanılır? 

*Kod tekrarının önüne geçer ve birden fazla yol kullanarak gerçekleştirmemize yarar.

3-Bir metodun private, protected ya da public olması kavramlarını açıklayınız.

*public methodlarda sınıfın her yerinden ve farklı sınıflardan erişebiliriz.
*private methodlarda sadece ilgili clastan erişebiliriz bu class dışından erişemeyiz
*protected methodlarda sınıf dışı erişim sağlanamaz sadece o sınıftan ve sınıftan miras alan sınıflar içinden erişim sağlayabiliriz


4-(Abstraction) Soyutlama nedir?

*Kullanıcıdan gereksiz ayrıntıları gizleyerek karışıklığın önüne geçmektir.


![uml](https://user-images.githubusercontent.com/85164822/174446858-519f6cde-46a1-4bff-8e83-86b202aab379.png)
